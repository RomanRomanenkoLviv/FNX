<section class="main login">
	<h1>Login</h1>
	<form action="" method="post" class="loginform">
		<label><p>Login:</p><input type="text" name="login"></label>
		<label><p>Password:</p><input type="password" name="password"></label>
		<button type="submit" name="loginuser">Confirm</button>
	</form>
</section>